<?php

$conn = mysqli_connect('localhost','root','','shop_cart') or die('connection failed');

?>