<footer class="f-card">
	<center>
		<h3>
			&#169;@2022 E-come
		</h3>		 
	</center>	
</footer>